package com.example.matthewruff.softwaredevelopmentproject1;

import android.inputmethodservice.Keyboard;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.GridLayout;
import android.widget.Button;

import java.util.Random;
import android.os.Handler;

import com.example.matthewruff.softwaredevelopmentproject1.R;

import java.util.logging.LogRecord;

public class MJ_MemoryGame extends AppCompatActivity implements View.OnClickListener {

    private MemoryGame4x4[] button;
    private MemoryGame4x4 First_Clicked_Button;
    private MemoryGame4x4 Second_Clicked_Button;

    private int Elements;
    private int[] Locations;
    private int[] Items;

    private boolean running;
    private boolean notrunning;
    private Button New_button;



    @Override
    //Oncreate makes a grid layout with the pictures on small cards, scrambles their positions, and sets up the game
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mj__memory_game);

        GridLayout gridLayout = (GridLayout) findViewById(R.id.MJGridLayout);


        int Col = gridLayout.getColumnCount();
        int Row = gridLayout.getRowCount();

        Items = new int[Elements / 2];
        Items[0] = R.drawable.apple;
        Items[1] = R.drawable.orange;
        Items[2] = R.drawable.carrot;
        Items[3] = R.drawable.leopard;
        Items[4] = R.drawable.squash;
        Items[5] = R.drawable.watermelon;
        Items[6] = R.drawable.wolf;
        Items[7] = R.drawable.tomato;
        Elements = Col * Row;
        button = new MemoryGame4x4[Elements];



        Locations = new int[Elements];


        scramble();
        for (int rows = 0; rows < Row; rows++) {

            for (int cols = 0; cols < Col; cols++) {
                //Creates the platform for the  4 by 4 memory game
                MemoryGame4x4 tempButton = new MemoryGame4x4(this, rows, cols, Items[Locations[rows * Col + cols]]);
                gridLayout.addView(tempButton);
                tempButton.setId(View.generateViewId());
                tempButton.setOnClickListener(this);
                button[rows * Col + cols] = tempButton;
                gridLayout.addView(tempButton);
            }
        }
    }



    @Override
    //Handles what happens when a player clicks on a card
    public void onClick(View v) {

        if (running)
            return;

        MemoryGame4x4 Buttons = (MemoryGame4x4) v;
        //If it matches remove card, if there is no card then that spot cannot be clicked on
        if (Buttons.Match)
            return;

        if (First_Clicked_Button == null) {
            First_Clicked_Button = Buttons;
            First_Clicked_Button.IsFlipped();
            return;
        }

        if (First_Clicked_Button.getId() == Buttons.getId())
        {
            return;
        }

        if (First_Clicked_Button.getFrontDrawableId() == Buttons.getFrontDrawableId()) {
            Buttons.IsFlipped();
            Buttons.setMatch(true);
            First_Clicked_Button.setMatch(true);
            First_Clicked_Button.setEnabled(false);
            Buttons.setEnabled(false);

            First_Clicked_Button = null;
            return;
        }


        else
        {
            Second_Clicked_Button = Buttons;
            Second_Clicked_Button.IsFlipped();
            running = true;

          final Handler handler = new Handler();
            //A player could possibly spam the click button, this prevents them to do an action for .5 seconds
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Second_Clicked_Button.IsFlipped();
                    First_Clicked_Button.IsFlipped();
                    Second_Clicked_Button = null;
                    First_Clicked_Button = null;
                    running = false;
                }
            }, 500);


        }
    }
    //When the images load they will be ordered and it must be scrambled to increase difficulty.
    protected void scramble() {

        Random random = new Random();

        for (int i = 0; i < Elements; i++) {
            Locations[i] = i % 8;
        }
        for (int i = 0; i < Elements; i++) {
            int Stored_Val = Locations[i];

            int Random_Move = random.nextInt(16);

            Locations[i] = Locations[Random_Move];

            Locations[Random_Move] = Stored_Val;
        }
    }
}