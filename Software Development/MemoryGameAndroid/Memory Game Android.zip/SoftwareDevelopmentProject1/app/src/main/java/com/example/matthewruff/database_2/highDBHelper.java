package com.example.matthewruff.database_2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class highDBHelper extends SQLiteOpenHelper {
    public highDBHelper(Context context) {
        super(context, "scoreDB", null, 1);
    }

    @Override
    //Creates a table to put names and scores
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE SCORE (_id INTEGER PRIMARY KEY AUTOINCREMENT, NAME TEXT, HIGHSCORE TEXT);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS SCORE");
        onCreate(db);
    }
    //Adds player name and score
    public static void insertItem(SQLiteDatabase db, String name, String score) {
        ContentValues cv = new ContentValues();
        cv.put("NAME", name);
        cv.put("HIGHSCORE", score);
        db.insert("SCORE", null, cv);
    }
    //removes entry
    public static void deleteItem(SQLiteDatabase db, int id) {
        db.delete("SCORE", "_id = ?", new String[] {"" + id});
    }
    //getting scores
    public static String getAllItemsString(SQLiteDatabase db) {
        String s = "";
        Cursor cursor = db.rawQuery("SELECT  * FROM SCORE", null);
        cursor.moveToFirst();
        s += cursor.getString(1) + " " + cursor.getString(2);
        while (cursor.moveToNext())
            s += "\n" + cursor.getString(1) + " " + cursor.getString(2);
        cursor.close();
        return s;
    }
}