package com.example.matthewruff.softwaredevelopmentproject1;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.v7.widget.AppCompatDrawableManager;
import android.widget.Button;
import android.widget.GridLayout;

import com.example.matthewruff.softwaredevelopmentproject1.R;

/**
 * Created by Ziah on 5/3/2017.
 */

//Subclasses to make a 4x4 memory game.
public class MemoryGame4x4 extends android.support.v7.widget.AppCompatButton {

    protected Drawable first;
    protected Drawable second;

    protected int col;
    protected int row;
    protected int Image;
    protected boolean Match = false;
    protected boolean NoneMatch = false;

    public MemoryGame4x4(Context context, int r, int c, int frontImageDrawableId){

        super(context);


        first = AppCompatDrawableManager.get().getDrawable(context, frontImageDrawableId);
        second = AppCompatDrawableManager.get().getDrawable(context, R.drawable.image_back);
        row = r;
        col = c;
        Image = frontImageDrawableId;





        setBackground(second);

        GridLayout.LayoutParams Params = new GridLayout.LayoutParams(GridLayout.spec(r),GridLayout.spec(c));
        setLayoutParams(Params);
        Params.width = (int) getResources().getDisplayMetrics().density *100;
        Params.height = (int) getResources().getDisplayMetrics().density *100;

    }


    public boolean Match(){

        return Match;
    }
    //checks to see if there is a match
    public void setMatch(boolean match){
        Match();
        Match = match ;

    }
    //Finds the image of the card being created
    public int getFrontDrawableId(){

        return Image;
    }

    //Finds the front image of the card being created
    public Drawable getFirst() {
        return first;
    }
    //Checks to see what card gets flipped face up and checks to see if another match.
    public void IsFlipped(){
        if(Match)
            return;
        if(NoneMatch){
            setBackground(second);
            NoneMatch = false;
        }
        else
            setBackground(first);
            NoneMatch = true;
    }
}
