package com.example.matthewruff.softwaredevelopmentproject1;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.matthewruff.database_2.highDBHelper;
import com.example.matthewruff.softwaredevelopmentproject1.R;


public class MainActivity extends AppCompatActivity {


    private Button button;
    private Intent Intent;
    private TextView textView;
    private EditText editText,editScore;
    private String name;
    private int score;
    public static final int DEFAULT=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Button button1 = (Button) findViewById(R.id.button1);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Intent = new Intent(MainActivity.this, MJ_MemoryGame.class);
                startActivity(Intent);
            }
        });


        textView = (TextView) findViewById(R.id.textView);
        editText = (EditText) findViewById(R.id.editText);
        editScore = (EditText) findViewById(R.id.editScore);
        //Intent intent = getIntent();
        name = "" + editText.getText();
        score = Integer.valueOf(String.valueOf(editScore.getText()));
    }

    public void save (View view){
        SharedPreferences prefs = this.getSharedPreferences("myPrefsKey", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt("High Score",score);
        editor.commit();

    }
    public void load(View view){
        SharedPreferences sharedPreferences = getSharedPreferences("MyData", Context.MODE_PRIVATE);
        int highScore = sharedPreferences.getInt("High Score",DEFAULT);
    }
    public void handleAddClick(View v) {
		/* This code adds a new item to the database. */
        /*SQLiteDatabase db = new highDBHelper(this).getReadableDatabase();
        highDBHelper.insertItem(db,);
        Toast.makeText(MainActivity.this, "Added new item", Toast.LENGTH_LONG).show();
        db.close();*/

        textView.setText("" + score);


    }

    public void handleViewClick(View v) {
		/* This reads the contents of the database and displays them. */
        SQLiteDatabase db = new highDBHelper(this).getReadableDatabase();
        String s = highDBHelper.getAllItemsString(db);
        textView.setText(s);
        db.close();
    }

}

